# face-detection-module

Reusable React face detection component. Detects faces via webcam, draws landmarks, and plays a loud alert when no face is detected after a grace period.

---

## Adding to another project

### Method 1 — Local install (recommended while developing)

In your other project's root:

```bash
npm install ../path/to/face-detection-module
```

Example if both projects sit side by side:

```bash
npm install ../face-detection-module
```

Then install the required peer dependency:

```bash
npm install @vladmandic/face-api
```

---

### Method 2 — Pack as a tarball (portable, no path dependency)

Inside this module folder:

```bash
npm run build:lib
npm pack
```

This creates `face-detection-module-1.0.0.tgz`. Copy that file to your other project and install it:

```bash
npm install ./face-detection-module-1.0.0.tgz
```

---

### Method 3 — Publish to npm (for team/production use)

```bash
npm run build:lib
npm publish
```

Then in any project:

```bash
npm install face-detection-module @vladmandic/face-api
```

---

## Usage

```jsx
import { FaceDetector } from 'face-detection-module';

export default function App() {
  return (
    <FaceDetector
      width={640}
      height={480}
      noFaceGrace={3000}       // wait 3s before alerting (ms)
      alertOnNoFace={true}     // beep when no face after grace period
      alertOnFace={false}      // beep when face IS detected
      alertCooldown={3000}     // min ms between beeps
      onFaceDetected={(d) => console.log(`${d.length} face(s)`)}
      onNoFace={() => console.log('No face!')}
    />
  );
}
```

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| width | number | 640 | Video width px |
| height | number | 480 | Video height px |
| interval | number | 150 | Detection interval ms |
| minConfidence | number | 0.5 | Min face score 0–1 |
| noFaceGrace | number | 3000 | Ms to wait before firing onNoFace |
| alertCooldown | number | 3000 | Min ms between sound alerts |
| alertOnFace | boolean | false | Beep when face detected |
| alertOnNoFace | boolean | true | Beep when no face after grace |
| showOverlay | boolean | true | Draw bounding boxes + landmarks |
| onFaceDetected | function | — | Called with detections array |
| onNoFace | function | — | Called after grace period |
| style | object | — | Wrapper div style overrides |
