import React from "react";
import { Routes, Route, MemoryRouter } from "react-router-dom";
import { ThemeProvider } from "./ThemeContext";
import Playground from "./pages/Playground";
import JoinRoom from "./pages/JoinRoom";

/**
 * SketchlyCanvas
 *
 * Props:
 *   serverUrl  {string}  URL of the Sketchly backend  (default: http://localhost:4000)
 *   roomId     {string}  Pre-set room ID to jump straight into (optional)
 *   username   {string}  Pre-set display name (optional)
 *   asHost     {boolean} Join as host (skips join screen)  (default: false)
 */
const SketchlyCanvas = ({ serverUrl, roomId, username, asHost = false }) => {
  // Expose serverUrl globally so Playground/JoinRoom can pick it up
  if (serverUrl) window.__SKETCHLY_URL__ = serverUrl;

  // Build the initial path for MemoryRouter
  let initialPath = "/";
  if (roomId) {
    const query = [];
    if (username) query.push(`name=${encodeURIComponent(username)}`);
    if (asHost) query.push("host=true");
    initialPath = `/playground/${roomId}${query.length ? "?" + query.join("&") : ""}`;
  }

  return (
    <ThemeProvider>
      <MemoryRouter initialEntries={[initialPath]}>
        <Routes>
          <Route path="/playground/:roomId" element={<Playground />} />
          <Route path="/join/:roomId" element={<JoinRoom />} />
        </Routes>
      </MemoryRouter>
    </ThemeProvider>
  );
};

export default SketchlyCanvas;
