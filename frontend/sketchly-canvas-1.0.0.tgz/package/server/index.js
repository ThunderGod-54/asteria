import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" }));

const server = createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
  maxHttpBufferSize: 50e6,
});

const rooms = {};

function getRoom(roomId) {
  if (!rooms[roomId]) rooms[roomId] = { shapes: [], users: {}, markers: [] };
  return rooms[roomId];
}

app.get("/room/:roomId", (req, res) => {
  const room = getRoom(req.params.roomId);
  res.json({ shapes: room.shapes, userCount: Object.keys(room.users).length });
});

io.on("connection", (socket) => {
  let currentRoom = null;
  let currentUser = null;

  socket.on("join-room", ({ roomId, username }) => {
    const room = getRoom(roomId);
    if (Object.keys(room.users).length >= 10) { socket.emit("room-full"); return; }
    currentRoom = roomId;
    currentUser = { id: socket.id, username: username || `User-${socket.id.slice(0, 4)}`, color: randomColor() };
    socket.join(roomId);
    room.users[socket.id] = currentUser;
    socket.emit("room-state", { shapes: room.shapes, users: Object.values(room.users), markers: room.markers });
    socket.to(roomId).emit("user-joined", currentUser);
    io.to(roomId).emit("users-update", Object.values(room.users));
  });

  socket.on("cursor-move", ({ x, y }) => {
    if (!currentRoom) return;
    socket.to(currentRoom).emit("cursor-update", { userId: socket.id, x, y, ...currentUser });
  });

  socket.on("shape-add", (shape) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    if (!shape.id) shape.id = uuidv4();
    room.shapes.push(shape);
    socket.to(currentRoom).emit("shape-add", shape);
  });

  socket.on("shape-update", (shape) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    const idx = room.shapes.findIndex((s) => s.id === shape.id);
    if (idx !== -1) room.shapes[idx] = shape;
    socket.to(currentRoom).emit("shape-update", shape);
  });

  socket.on("shape-delete", (shapeId) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    room.shapes = room.shapes.filter((s) => s.id !== shapeId);
    socket.to(currentRoom).emit("shape-delete", shapeId);
  });

  socket.on("canvas-clear", () => {
    if (!currentRoom) return;
    getRoom(currentRoom).shapes = [];
    io.to(currentRoom).emit("canvas-clear");
  });

  socket.on("draw-stroke", (stroke) => {
    if (!currentRoom) return;
    socket.to(currentRoom).emit("draw-stroke", stroke);
  });

  socket.on("marker-add", (marker) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    room.markers.push(marker);
    socket.to(currentRoom).emit("marker-add", marker);
  });

  socket.on("marker-update", (marker) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    const idx = room.markers.findIndex(m => m.id === marker.id);
    if (idx !== -1) room.markers[idx] = marker;
    socket.to(currentRoom).emit("marker-update", marker);
  });

  socket.on("marker-delete", (id) => {
    if (!currentRoom) return;
    const room = getRoom(currentRoom);
    room.markers = room.markers.filter(m => m.id !== id);
    socket.to(currentRoom).emit("marker-delete", id);
  });

  socket.on("voice-join", () => { if (currentRoom) socket.to(currentRoom).emit("voice-user-joined", { userId: socket.id, ...currentUser }); });
  socket.on("voice-offer", ({ to, offer }) => { io.to(to).emit("voice-offer", { from: socket.id, offer }); });
  socket.on("voice-answer", ({ to, answer }) => { io.to(to).emit("voice-answer", { from: socket.id, answer }); });
  socket.on("voice-ice", ({ to, candidate }) => { io.to(to).emit("voice-ice", { from: socket.id, candidate }); });
  socket.on("voice-leave", () => { if (currentRoom) socket.to(currentRoom).emit("voice-user-left", { userId: socket.id }); });

  socket.on("disconnect", () => {
    if (!currentRoom) return;
    const room = rooms[currentRoom];
    if (room) {
      delete room.users[socket.id];
      io.to(currentRoom).emit("user-left", socket.id);
      io.to(currentRoom).emit("users-update", Object.values(room.users));
    }
  });
});

function randomColor() {
  const colors = ["#f87171", "#fb923c", "#facc15", "#4ade80", "#60a5fa", "#c084fc", "#f472b6"];
  return colors[Math.floor(Math.random() * colors.length)];
}

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Sketchly canvas server running on http://localhost:${PORT}`));
