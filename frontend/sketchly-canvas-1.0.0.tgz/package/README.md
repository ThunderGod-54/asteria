# sketchly-canvas

A plug-and-play real-time collaborative canvas module — drawing, shapes, voice chat, comment markers, and more.

---

## Installation

Copy the `sketchly-canvas` folder into your project, then install its dependencies:

```bash
cd sketchly-canvas
npm install
```

---

## Step 1 — Start the backend server

The canvas needs a Socket.io server running. Start it with:

```bash
node sketchly-canvas/server/index.js
```

It runs on **port 4000** by default. To use a different port:

```bash
PORT=5000 node sketchly-canvas/server/index.js
```

---

## Step 2 — Use the component in your React app

```jsx
import SketchlyCanvas from "./sketchly-canvas/src";

function App() {
  return (
    <SketchlyCanvas
      serverUrl="http://localhost:4000"
      roomId="my-room-123"
      username="Alex"
      asHost={true}
    />
  );
}
```

### Props

| Prop        | Type    | Default                    | Description                              |
|-------------|---------|----------------------------|------------------------------------------|
| `serverUrl` | string  | `http://localhost:4000`    | URL of the Sketchly backend server       |
| `roomId`    | string  | —                          | Room ID to join directly                 |
| `username`  | string  | auto-generated             | Display name shown to other users        |
| `asHost`    | boolean | `false`                    | Skip the join screen and enter as host   |

---

## Collaborating across different machines

If your friend is on a different PC or network, set `serverUrl` to the host machine's IP:

```jsx
<SketchlyCanvas serverUrl="http://192.168.1.x:4000" roomId="shared-room" username="Bob" />
```

Or use [ngrok](https://ngrok.com) to expose the server publicly:

```bash
ngrok http 4000
# gives you: https://abc123.ngrok.io
```

```jsx
<SketchlyCanvas serverUrl="https://abc123.ngrok.io" roomId="shared-room" username="Bob" />
```

---

## Requirements

- Node.js 18+
- React 18+
- react-router-dom 6+
